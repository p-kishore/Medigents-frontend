import { motion } from "framer-motion";
import { ShieldCheck, Workflow, Bot, GraduationCap, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const solutions = [
  {
    icon: ShieldCheck,
    title: "AI Governance & Compliance",
    desc: "Automated policy enforcement and risk detection for all AI tools used in your clinic.",
    color: "text-blue-600",
    bg: "bg-blue-50"
  },
  {
    icon: Workflow,
    title: "Workflow Automation",
    desc: "Smart routing for patient inquiries, lab results, and appointment scheduling.",
    color: "text-teal-600",
    bg: "bg-teal-50"
  },
  {
    icon: Bot,
    title: "AI Agents (Voice + WhatsApp)",
    desc: "24/7 patient support agents that handle booking and triage seamlessly.",
    color: "text-purple-600",
    bg: "bg-purple-50"
  },
  {
    icon: GraduationCap,
    title: "Doctor & Staff AI Training",
    desc: "Interactive modules to upskill your team on safe AI usage and best practices.",
    color: "text-orange-600",
    bg: "bg-orange-50"
  }
];

export default function CoreSolutions() {
  return (
    <section id="solutions" className="py-24 bg-slate-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <span className="text-primary font-semibold text-sm tracking-wider uppercase mb-2 block">Our Solutions</span>
            <h2 className="text-3xl md:text-4xl font-bold font-display text-slate-900">
              Everything you need to be <br/> an AI-First Clinic
            </h2>
          </div>
          <Button variant="ghost" className="text-primary hover:text-teal-700 group">
            View all features <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {solutions.map((sol, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100"
            >
              <div className={`w-14 h-14 rounded-2xl ${sol.bg} ${sol.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                <sol.icon className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">{sol.title}</h3>
              <p className="text-slate-600 text-lg leading-relaxed mb-6">
                {sol.desc}
              </p>
              <div className="flex items-center text-sm font-semibold text-slate-400 group-hover:text-primary transition-colors cursor-pointer">
                Learn more <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
