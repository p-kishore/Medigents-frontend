import { motion } from "framer-motion";
import { Search, ScrollText, Cpu, CheckCircle } from "lucide-react";

const steps = [
  {
    id: "01",
    title: "Risk Audit",
    desc: "We analyze your current workflows and identify hidden AI risks.",
    icon: Search,
    color: "bg-blue-100 text-blue-600"
  },
  {
    id: "02",
    title: "Governance Blueprint",
    desc: "Custom AI policies and compliance frameworks for your clinic.",
    icon: ScrollText,
    color: "bg-teal-100 text-teal-600"
  },
  {
    id: "03",
    title: "Automation & Agents",
    desc: "Deploy secure AI agents for scheduling, notes, and triage.",
    icon: Cpu,
    color: "bg-indigo-100 text-indigo-600"
  },
  {
    id: "04",
    title: "Continuous Compliance",
    desc: "Real-time monitoring ensures you stay safe as AI evolves.",
    icon: CheckCircle,
    color: "bg-green-100 text-green-600"
  }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:14px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <span className="text-teal-400 font-semibold text-sm tracking-wider uppercase mb-2 block">Process</span>
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">
            From Chaos to Control
          </h2>
          <p className="text-slate-400 text-lg">
            Our proven 4-step methodology to modernize your healthcare practice safely.
          </p>
        </div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-800 -translate-y-1/2 hidden lg:block" />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
            {steps.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className="relative group"
              >
                <div className={`w-16 h-16 rounded-2xl ${step.color} flex items-center justify-center mb-6 relative z-10 shadow-xl mx-auto lg:mx-0 transition-transform group-hover:-translate-y-2`}>
                  <step.icon className="w-8 h-8" />
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-white rounded-full flex items-center justify-center text-xs font-bold text-slate-900 border-2 border-slate-900">
                    {step.id}
                  </div>
                </div>
                
                <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                <p className="text-slate-400 leading-relaxed text-sm">
                  {step.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
