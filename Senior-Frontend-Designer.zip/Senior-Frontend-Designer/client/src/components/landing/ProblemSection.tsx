import { motion } from "framer-motion";
import { AlertTriangle, Clock, FileWarning, Scale, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const problems = [
  {
    icon: FileWarning,
    title: "No AI Usage Policy",
    desc: "Staff using unauthorized tools risks patient data leakage."
  },
  {
    icon: Scale,
    title: "Legal & Compliance Risk",
    desc: "HIPAA & DPDP violations can lead to massive fines."
  },
  {
    icon: Clock,
    title: "Manual Workflows",
    desc: "Hours lost daily on documentation and scheduling."
  },
  {
    icon: Users,
    title: "Staff Burnout",
    desc: "Overworked medical teams lead to errors and turnover."
  }
];

export default function ProblemSection() {
  return (
    <section className="py-24 bg-white relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-red-500 font-semibold text-sm tracking-wider uppercase mb-2 block">The Challenge</span>
          <h2 className="text-3xl md:text-4xl font-bold font-display text-slate-900 mb-4">
            Healthcare is adopting AI — <br/>
            <span className="text-slate-400">without control.</span>
          </h2>
          <p className="text-slate-600 text-lg">
            Rapid AI adoption brings efficiency, but also unprecedented risks for clinics operating without a governance framework.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {problems.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
            >
              <Card className="h-full border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group bg-slate-50/50 hover:bg-white hover:border-red-100">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-red-50 text-red-500 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <item.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">{item.title}</h3>
                  <p className="text-slate-600 leading-relaxed">{item.desc}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
