import { Check } from "lucide-react";

export default function Benefits() {
  const benefits = [
    "40-70% Reduction in Admin Workload",
    "Zero Compliance Violations",
    "24/7 Patient Response Time",
    "Reduced Staff Burnout",
    "Seamless EMR Integration",
    "Data-Driven Operational Insights"
  ];

  return (
    <section id="benefits" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-8 md:p-16 text-white overflow-hidden relative">
          {/* Abstract blobs */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/20 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/20 blur-[100px] rounded-full translate-y-1/2 -translate-x-1/2"></div>
          
          <div className="relative z-10 grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-5xl font-bold font-display mb-6">
                Why Top Clinics <br/> Choose MediGents
              </h2>
              <p className="text-slate-300 text-lg mb-8 max-w-md">
                Don't get left behind. Join the healthcare revolution with tools designed for the future of medicine.
              </p>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-6">
              {benefits.map((benefit, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="mt-1 w-5 h-5 rounded-full bg-teal-500 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                  <span className="font-medium text-lg">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
