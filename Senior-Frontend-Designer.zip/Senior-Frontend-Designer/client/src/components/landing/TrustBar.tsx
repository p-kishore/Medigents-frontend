import { Shield, Activity, Brain, Stethoscope, FileCheck, Lock } from "lucide-react";

export default function TrustBar() {
  const logos = [
    { name: "HIPAA Compliant", icon: Shield },
    { name: "SOC2 Ready", icon: Lock },
    { name: "Clinical Grade", icon: Stethoscope },
    { name: "GDPR Safe", icon: FileCheck },
    { name: "AI Governance", icon: Brain },
    { name: "24/7 Monitoring", icon: Activity },
  ];

  return (
    <section className="py-10 border-y border-slate-100 bg-slate-50/50">
      <div className="container mx-auto px-4">
        <p className="text-center text-sm font-medium text-slate-500 mb-8 uppercase tracking-widest">
          Built with Doctors • Designed for Compliance • 2026 AI-Ready
        </p>
        
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-70 grayscale hover:grayscale-0 transition-all duration-500">
          {logos.map((Logo, idx) => (
            <div key={idx} className="flex items-center gap-2 group cursor-default">
              <Logo.icon className="w-6 h-6 text-slate-400 group-hover:text-teal-600 transition-colors" />
              <span className="text-sm font-semibold text-slate-400 group-hover:text-slate-700 transition-colors">
                {Logo.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
