import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck, Activity, Brain } from "lucide-react";
import heroVisual from "@assets/generated_images/abstract_medical_ai_hero_illustration.png";

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 right-0 h-[800px] bg-gradient-to-b from-teal-50/50 to-white -z-10" />
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-bl from-blue-50/50 to-transparent -z-10 blur-3xl opacity-60" />
      
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 border border-teal-100 text-teal-700 text-sm font-medium mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
              </span>
              Accepting Early Access Partners
            </div>
            
            <h1 className="text-4xl md:text-6xl font-display font-bold leading-[1.1] mb-6 tracking-tight text-slate-900">
              AI Governance & <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-blue-600">
                Automation
              </span> for <br />
              Modern Healthcare
            </h1>
            
            <p className="text-lg md:text-xl text-slate-600 mb-8 max-w-lg leading-relaxed">
              Helping clinics and hospitals adopt AI safely, stay compliant, and reduce admin workload by 40%.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary hover:bg-teal-700 text-white rounded-full px-8 h-12 text-base shadow-xl shadow-teal-600/20 transition-all hover:scale-105">
                Join Early Access
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" className="rounded-full px-8 h-12 text-base border-slate-200 text-slate-700 hover:bg-slate-50">
                Get Free AI Risk Audit
              </Button>
            </div>

            <div className="mt-10 flex items-center gap-6 text-sm text-slate-500 font-medium">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-teal-500" />
                <span>HIPAA Compliant</span>
              </div>
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-500" />
                <span>Risk-Free AI</span>
              </div>
            </div>
          </motion.div>

          {/* Hero Visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            {/* Floating Elements Animation */}
            <motion.div 
              animate={{ y: [0, -20, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="relative z-10 rounded-2xl overflow-hidden shadow-2xl shadow-blue-900/10 border border-white/50 bg-white/40 backdrop-blur-sm"
            >
              <img 
                src={heroVisual} 
                alt="AI Healthcare Dashboard" 
                className="w-full h-auto object-cover rounded-2xl"
              />
              
              {/* Overlay Mockup Elements */}
              <div className="absolute top-10 right-[-20px] bg-white p-4 rounded-xl shadow-lg border border-slate-100 hidden md:block animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-500 fill-mode-forwards opacity-0">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                    <Activity className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">Efficiency Score</div>
                    <div className="text-sm font-bold text-slate-800">+42% Increase</div>
                  </div>
                </div>
              </div>

              <div className="absolute bottom-10 left-[-20px] bg-white p-4 rounded-xl shadow-lg border border-slate-100 hidden md:block animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-700 fill-mode-forwards opacity-0">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <ShieldCheck className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">Compliance Status</div>
                    <div className="text-sm font-bold text-slate-800">100% Verified</div>
                  </div>
                </div>
              </div>

            </motion.div>
            
            {/* Background Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-teal-400/20 blur-[100px] -z-10 rounded-full" />
          </motion.div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-400"
      >
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <motion.div 
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-1 h-8 rounded-full bg-slate-200 overflow-hidden"
        >
          <div className="w-full h-1/2 bg-slate-400 rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  );
}
