import Navbar from "@/components/landing/Navbar";
import Hero from "@/components/landing/Hero";
import TrustBar from "@/components/landing/TrustBar";
import ProblemSection from "@/components/landing/ProblemSection";
import HowItWorks from "@/components/landing/HowItWorks";
import CoreSolutions from "@/components/landing/CoreSolutions";
import Benefits from "@/components/landing/Benefits";
import WaitlistForm from "@/components/landing/WaitlistForm";
import Footer from "@/components/landing/Footer";
import subtleBg from "@assets/generated_images/subtle_light_mesh_gradient_background.png";

export default function Home() {
  return (
    <div className="min-h-screen font-sans bg-background text-foreground overflow-x-hidden selection:bg-teal-100 selection:text-teal-900">
      <Navbar />
      <main>
        <Hero />
        <TrustBar />
        <div style={{ backgroundImage: `url(${subtleBg})`, backgroundSize: 'cover' }}>
          <ProblemSection />
          <HowItWorks />
        </div>
        <CoreSolutions />
        <Benefits />
        <WaitlistForm />
      </main>
      <Footer />
    </div>
  );
}
