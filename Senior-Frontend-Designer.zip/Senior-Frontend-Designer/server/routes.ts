import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistSignupSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/waitlist", async (req, res) => {
    try {
      const validatedData = insertWaitlistSignupSchema.parse(req.body);
      const signup = await storage.createWaitlistSignup(validatedData);
      res.status(201).json({ success: true, data: signup });
    } catch (error) {
      console.error("Waitlist signup error:", error);
      res.status(400).json({ 
        success: false, 
        error: error instanceof Error ? error.message : "Invalid request" 
      });
    }
  });

  app.get("/api/waitlist", async (req, res) => {
    try {
      const signups = await storage.getAllWaitlistSignups();
      res.json({ success: true, data: signups });
    } catch (error) {
      console.error("Error fetching waitlist:", error);
      res.status(500).json({ 
        success: false, 
        error: "Failed to fetch waitlist" 
      });
    }
  });

  return httpServer;
}
